const express = require("express");
const morgan = require("morgan");
const app = express();
const PORT = 8081;
app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
const cors = require("cors");
app.use(
	cors({
		origin: true,
	})
);

app.get("/", (req, res) => {
  return res.json({ hello: "helloworld" });
});

app.listen(PORT, () => console.log(`this server listening on ${PORT}`));
